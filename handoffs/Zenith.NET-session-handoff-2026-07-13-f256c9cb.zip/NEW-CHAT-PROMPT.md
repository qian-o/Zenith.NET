# New Conversation Prompt

I am continuing work on `qian-o/Zenith.NET` from a previous GitHub Copilot conversation. Read the attached `CURRENT-CONTEXT.md` first. Use `chat/readable-transcript.md` only when you need to trace a specific decision.

Work on branch `refactor/rhi-redesign` and pull its latest commit before changing files. The DocFX redesign has been committed. Do not restore the removed `.config/dotnet-tools.json`, and do not restore the previously abandoned Vulkan device-loss experiments.

The current focus is pixel-level refinement of the DocFX Landing page using real browser screenshots and DOM measurements. Preserve the six-section information architecture, unified light/dark canvases, responsive behavior, Hero composition, and the manually controlled C# semantic coloring in the Architecture code panel.

Before editing, verify the current page and report what you read from the repository. Then follow my next request without broadening the scope.
