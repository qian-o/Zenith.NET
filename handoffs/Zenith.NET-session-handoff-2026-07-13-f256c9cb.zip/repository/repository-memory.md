# Zenith.NET Repository Memory

- Cross-platform .NET GPU abstraction targeting DirectX 12, Metal 4, and Vulkan 1.4 on .NET 10.
- Source lives under `sources/`; DocFX documentation lives under `documents/`.
- Core dependencies flow from Core to Backends, Extensions, and Views. Backends are usually created through `GraphicsContext` extension factories.
- Core concepts include `GraphicsContext`, command queues, pooled command buffers, timeline values, bindless resources, and explicit synchronization.
- Slangc.NET produces DXIL, metallib, or SPIR-V and reflects thread-group sizes.
- View layers do not own `GraphicsContext`.
- There is no unified deferred-destruction system; callers must respect GPU lifetime and backend ownership.
- Documentation must follow current source contracts rather than old generated API YAML or legacy `ResourceTable` and `FrameBuffer` prose.
- The Landing page uses continuous Raw HTML and a six-section structure. Main responsive breakpoints are 992, 768, and 576px.
- The NVIDIA descriptor-heap/ray-query device-loss investigation is paused and all experiments were reverted.
