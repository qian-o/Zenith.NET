# Zenith.NET Session Handoff

Session ID: `f256c9cb-1ea5-4567-8e81-d968bd3b4fc4`  
Created: 2026-07-13

This archive carries the current GitHub Copilot conversation and working context to another computer.

## Continue on the company computer

1. Pull the latest `refactor/rhi-redesign` branch. The DocFX redesign is committed to Git.
2. Attach `NEW-CHAT-PROMPT.md` and `CURRENT-CONTEXT.md` to a new GitHub Copilot conversation.
3. Use `chat/readable-transcript.md` when a decision needs to be traced. The raw VS Code event stream is in `chat/full-session-transcript.jsonl`.
4. Run the strict DocFX build and open a fresh local preview before making more visual changes.

The original browser page ID cannot be transferred between VS Code installations. Open and share a new browser page on the company computer.

## Archive contents

- `NEW-CHAT-PROMPT.md`: ready-to-use first prompt for the new conversation.
- `CURRENT-CONTEXT.md`: current technical and visual state.
- `chat/readable-transcript.md`: chronological user and assistant messages.
- `chat/full-session-transcript.jsonl`: full raw VS Code Copilot event stream.
- `chat/session-resources/`: screenshots and long tool outputs.
- `repository/repository-memory.md`: repository-specific facts and conventions.

This archive intentionally does not include `.config/dotnet-tools.json` or a separate SHA file.
