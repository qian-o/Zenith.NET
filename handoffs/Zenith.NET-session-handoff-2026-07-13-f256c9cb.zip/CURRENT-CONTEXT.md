# Current Context

## Repository

- Repository: `https://github.com/qian-o/Zenith.NET`
- Branch: `refactor/rhi-redesign`
- Solution: `Zenith.NET.slnx`
- Target platform: .NET 10
- Documentation: DocFX Modern template
- The DocFX redesign is committed under the English subject `Redesign DocFX documentation site`.
- `.config/dotnet-tools.json` was intentionally removed and must not be restored.

## Current Objective

Continue refining the Zenith.NET DocFX documentation site. The Landing page is a continuous six-section experience:

1. Real rendering Hero.
2. 3x2 Features.
3. Architecture split layout with code panel.
4. Quick Start install strip.
5. Three Resources items.
6. Informational Footer.

The light canvas is `#fbfafc`; the dark canvas is `#100d16`. The primary brand color is official `.NET Purple #512BD4`, with restrained cyan, pink, and warm semantic code colors. Main breakpoints are 992, 768, and 576px. The wide content shell is capped at 1440px.

## Hero State

- Desktop Hero height is 620px.
- The image uses a full-height, 82%-wide right-side layer rather than center scaling.
- At 1536x900, the Hero and image both start at 68px; top and bottom image gaps are 0px.
- Below 992px, the existing centered `scale(1.015)` composition is retained.
- The bottom fade, unified canvas, and dark-tablet blend have been validated.

## Architecture Code Panel

The opening code is intentionally displayed as:

```csharp
using Zenith.NET;
using Zenith.NET.Vulkan;

using GraphicsContext context = GraphicsContext.CreateVulkan(bool: useValidationLayer);
```

`bool: useValidationLayer` is user-requested visual pseudocode and is not required to compile.

Formatting and color constraints:

- Exactly one blank line follows the two namespace imports.
- `pre` padding is `30px 32px`.
- Measured visual gaps: top `32.67px`, left `32px`, bottom `33.97px`.
- Manual semantic spans are used: `.code-keyword`, `.code-namespace`, `.code-type`, `.code-method`, `.code-value`, `.code-comment`, and `.code-number`.
- The code node uses `class="language-csharp nohighlight" data-highlighted="yes"` so DocFX does not rewrite the spans.
- Methods: warm yellow `#f0d775`, weight 600.
- Types and namespaces: cyan-green `#6ed6c1`.
- Keywords: magenta-purple `#d98cef`.
- Strings: warm orange `#d9a084`.
- Comments: green `#8fbc7a`.
- Numbers: `#b8d7a3`.
- Plain text: neutral `#d4d4d4`.
- Do not use blue foreground colors in this panel.

## Validation State

The last website validation passed:

- DocFX strict build: 0 warnings, 0 errors.
- `git diff --check`: no output.
- Relevant editor diagnostics: none.
- Desktop 1536x900: no page-level horizontal overflow.
- Mobile 390x844: no page-level horizontal overflow; long code scrolls only inside its code panel.
- No failed images.
- Ten method names retained the intended warm-yellow color after page load.

The local preview command used in the original session was:

```powershell
dotnet docfx documents/docfx.json --serve --hostname localhost --port 8080
```

DocFX 2.78.5 was used locally. Since the repository tool manifest was intentionally removed, install or invoke that version using the company environment rather than restoring `.config/dotnet-tools.json`.

## Important History

The investigation into NVIDIA `VK_EXT_descriptor_heap`, acceleration structures, inline ray queries, and `VK_ERROR_DEVICE_LOST` is finished. All experiment code was reverted. Do not reconstruct those experiments from the transcript unless the user explicitly reopens that work.

No current visual decisions should be inferred from old intermediate screenshots when a newer screenshot or measurement exists.
