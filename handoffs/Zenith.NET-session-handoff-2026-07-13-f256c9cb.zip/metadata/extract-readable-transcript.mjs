import { createReadStream, createWriteStream } from 'node:fs';
import { once } from 'node:events';
import { createInterface } from 'node:readline';
import { resolve } from 'node:path';

const inputPath = resolve(process.argv[2]);
const outputPath = resolve(process.argv[3]);
const output = createWriteStream(outputPath, { encoding: 'utf8' });

const write = async (text) => {
    if (!output.write(text)) await once(output, 'drain');
};

await write('# Zenith.NET GitHub Copilot Conversation\n\n');
await write('Extracted from the raw VS Code JSONL event stream. Tool events remain in the raw transcript.\n\n');

let count = 0;
const lines = createInterface({
    input: createReadStream(inputPath, { encoding: 'utf8' }),
    crlfDelay: Infinity
});

for await (const line of lines) {
    if (!line.trim()) continue;

    let event;
    try {
        event = JSON.parse(line);
    } catch {
        continue;
    }

    if (event.type !== 'user.message' && event.type !== 'assistant.message') continue;

    const content = event.data?.content;
    if (typeof content !== 'string' || !content.trim()) continue;

    const role = event.type === 'user.message' ? 'User' : 'GitHub Copilot';
    await write(`## ${role} - ${event.timestamp ?? 'unknown time'}\n\n`);
    await write(`${content.trimEnd()}\n\n`);
    count++;
}

output.end();
await once(output, 'finish');
console.log(count);