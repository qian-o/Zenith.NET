# Chat Files

- `readable-transcript.md` contains chronological user and assistant messages.
- `full-session-transcript.jsonl` is the complete raw VS Code GitHub Copilot event stream.
- `session-resources/` contains screenshots and long tool outputs referenced by the session.

The raw files contain local absolute paths and project details. Treat this archive like source code and do not publish it.
